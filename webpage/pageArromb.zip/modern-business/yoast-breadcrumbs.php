<?php if ( function_exists( 'yoast_breadcrumb' ) ) : // Breadcrumbs ?>
	<section class="breadcrumb">
		<?php yoast_breadcrumb( '<span id="breadcrumbs" class="breadcrumbs">','</span>' ); ?>
	</section>
<?php endif; ?>