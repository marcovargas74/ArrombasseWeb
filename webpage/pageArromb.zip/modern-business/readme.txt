/**
 * Font Awesome Web Font - http://fontawesome.io/
 * License: GPL Compatible (http://fontawesome.io/license/)
 * Font License: SIL OFL 1.1 (http://scripts.sil.org/OFL)
 * Code License: MIT License (http://opensource.org/licenses/mit-license.html)
 * Copyright: Dave Gandy, https://twitter.com/davegandy
 */

/**
 * WordPress Core CSS - http://codex.wordpress.org/CSS#WordPress_Generated_Classes
 * License: GPL2
 * Copyright: WordPress.org, http://wordpress.org
 */
 
 /**
 * CSS Reset - http://meyerweb.com/eric/tools/css/reset/
 * License: None (public domain)
 * Copyright: Eric Meyer, http://meyerweb.com/eric/
 *
 * We've used Eric Meyer's reset as a base and modified it a bit to suit our needs.
 */

/**
 * HTML5 Shiv - https://code.google.com/p/html5shiv/
 * License: Dual licensed under the MIT or GPL Version 2 licenses
 * Copyright: Alexander Farkas, http://protofunc.com/
 */

/**
 * WordPress 3.5 Media Uploader Script/Tutorial - http://mikejolley.com/2012/12/using-the-new-wordpress-3-5-media-uploader-in-plugins/
 * License: None (public domain)
 * Copyright: Mike Jolley, http://mikejolley.com/
 *
 * We've modified this to suit our needs.
 */

/**
 * Theme Screenshot Image - ./screenshot.png
 * License: GPL2
 * Copyright: Slocum Design Studio, http://slocumstudio.com/
 */

/**
 * Menu Icon Image - /images/menu-icon-large.png
 * License: GPL2
 * Copyright: Slocum Design Studio, http://slocumstudio.com/
 */

/**
 * Close Icon Image - /images/close-icon-large.png
 * License: GPL2
 * Copyright: Slocum Design Studio, http://slocumstudio.com/
 */